package com.example.jogoVivi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JogoViviApplication {

	public static void main(String[] args) {
		SpringApplication.run(JogoViviApplication.class, args);
	}

}
